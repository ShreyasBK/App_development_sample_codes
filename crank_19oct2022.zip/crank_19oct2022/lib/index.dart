// Export pages
export 'cranklineqc1_2_l/cranklineqc12_l_widget.dart' show Cranklineqc12LWidget;
export 'crankqcselect2_l/crankqcselect2_l_widget.dart'
    show Crankqcselect2LWidget;
export 'home_page_copy/home_page_copy_widget.dart' show HomePageCopyWidget;
export 'variantselect/variantselect_widget.dart' show VariantselectWidget;
export 'crank_associate_page_15_l/crank_associate_page15_l_widget.dart'
    show CrankAssociatePage15LWidget;
export 'crankqcselect1_5_l/crankqcselect15_l_widget.dart'
    show Crankqcselect15LWidget;
export 'summary_crank_qc1_2_l/summary_crank_qc12_l_widget.dart'
    show SummaryCrankQc12LWidget;
export 'cranklineqc1_15_l/cranklineqc115_l_widget.dart'
    show Cranklineqc115LWidget;
export 'cranklineqc2_15_l/cranklineqc215_l_widget.dart'
    show Cranklineqc215LWidget;
export 'crank_associate_page_2_l/crank_associate_page2_l_widget.dart'
    show CrankAssociatePage2LWidget;
export 'summary_crank_qc1_15_l/summary_crank_qc115_l_widget.dart'
    show SummaryCrankQc115LWidget;
export 'cranklineqc2_2_l/cranklineqc22_l_widget.dart' show Cranklineqc22LWidget;
export 'summary_crank_qc2_15_l/summary_crank_qc215_l_widget.dart'
    show SummaryCrankQc215LWidget;
export 'summary_crank_qc2_2_l/summary_crank_qc22_l_widget.dart'
    show SummaryCrankQc22LWidget;
export 'cranklineqc3_15_l/cranklineqc315_l_widget.dart'
    show Cranklineqc315LWidget;
export 'cranklineqc3_2_l/cranklineqc32_l_widget.dart' show Cranklineqc32LWidget;
export 'summary_crank_qc3_15_l/summary_crank_qc315_l_widget.dart'
    show SummaryCrankQc315LWidget;
export 'cranklineqc4_15_l/cranklineqc415_l_widget.dart'
    show Cranklineqc415LWidget;
export 'summary_crank_qc4_15_l/summary_crank_qc415_l_widget.dart'
    show SummaryCrankQc415LWidget;
export 'cranklineqc4_2_l/cranklineqc42_l_widget.dart' show Cranklineqc42LWidget;
export 'summary_crank_qc3_2_l/summary_crank_qc32_l_widget.dart'
    show SummaryCrankQc32LWidget;
export 'cranklineqc5_15_l/cranklineqc515_l_widget.dart'
    show Cranklineqc515LWidget;
export 'summary_crank_qc5_15_l/summary_crank_qc515_l_widget.dart'
    show SummaryCrankQc515LWidget;
export 'summary_crank_qc4_2_l/summary_crank_qc42_l_widget.dart'
    show SummaryCrankQc42LWidget;
export 'cranklineqc6_15_l/cranklineqc615_l_widget.dart'
    show Cranklineqc615LWidget;
export 'cranklineqc5_2_l/cranklineqc52_l_widget.dart' show Cranklineqc52LWidget;
export 'summary_crank_qc5_2_l/summary_crank_qc52_l_widget.dart'
    show SummaryCrankQc52LWidget;
export 'summary_crank_qc6_15_l/summary_crank_qc615_l_widget.dart'
    show SummaryCrankQc615LWidget;
export 'cranklineqc6_2_l/cranklineqc62_l_widget.dart' show Cranklineqc62LWidget;
export 'summary_crank_qc6_2_l/summary_crank_qc62_l_widget.dart'
    show SummaryCrankQc62LWidget;
export 'cranklineqc7_15_l/cranklineqc715_l_widget.dart'
    show Cranklineqc715LWidget;
export 'summary_crank_qc7_15_l/summary_crank_qc715_l_widget.dart'
    show SummaryCrankQc715LWidget;
export 'cranklineqc7_2_l/cranklineqc72_l_widget.dart' show Cranklineqc72LWidget;
export 'summary_crank_qc7_2_l/summary_crank_qc72_l_widget.dart'
    show SummaryCrankQc72LWidget;
