package com.mycompany.crankspeedbuildtest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
